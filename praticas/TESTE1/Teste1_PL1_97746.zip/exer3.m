clear all
close all

a = base3para10("120")
b = base3para10("012");

function x = base3para10(rep)
    x = str2num(rep(1))+10^str2num(rep(2))+str2num(rep(3));
end